using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using Fusion;
using Photon.Pun;


public class MultiplayerChat : NetworkBehaviour
{
    public Text _message;
    public Text input;
    public Text usernameInput;

    public Text textDone;
    
    public string username = "Default";
    
            public void SetUsername()
            {
                username=usernameInput.text;
            }

            public void CallMessageRPC()
            {
                {
                  
                  //if(username=="MA")
                  {
                    string message=input.text;
                    RPC_SendMessage(username,message);
                    input.text = " ";
                    }
                }
            }
            [Rpc(RpcSources.All,RpcTargets.All)]
            public void RPC_SendMessage(string username, string message , RpcInfo rpcInfo=default)
            {
                _message.text+=$"{username}: {message}\n";
                //DONE Texted
                TextChanged();
            }

            public void TextChanged()
            {
                textDone.text="M.ADONE";
            }

}
